const mongoose=require("mongoose")

mongoose.connect("mongodb://0.0.0.0/ullas")
.then(()=>{

    console.log("mongodb connected");
})
.catch(()=>{
    console.log("failed to connect");
})

const LogInSchema=new mongoose.Schema({
    firstname:{
        type:String,
        required:true
    },
    lastname:{
        type:String,
        required:true
    },
    emailid:{
        type:String,
        required:true
    },
     phonenumber:{
            type:String,
            required:true
        },
        password:{
            type:String,
            required:true
        },
        confirmpassword:{
        type:String,
        required:true
    }
    
})

const collection=new mongoose.model("user",LogInSchema)

module.exports=collection