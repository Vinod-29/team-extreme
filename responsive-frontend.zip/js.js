document.addEventListener('DOMContentLoaded', function() {
    const queryParams = new URLSearchParams(window.location.search);
    const detailsParam = queryParams.get('details');
    const selectedDetails = JSON.parse(decodeURIComponent(detailsParam));

    const formFieldsContainer = document.getElementById("form-fields");
    const registrationForm = document.getElementById("registration-form");

    selectedDetails.forEach(details => {
        let inputField = '';

        switch (details) {
            case 'event-date':
                inputField = `
                <div class="form-group">
              <label for="event-date">Event Date</label>
              <input type="date" class="form-control" id="event-date" name="event-date" required value="${queryParams.get('event-date') || ''}">
            </div>`;
                break;

            case 'event-time':
                inputField = `
            <div class="form-group">
              <label for="event-time">Event Time</label>
              <input type="time" class="form-control" id="event-time" name="event-time" required value="${queryParams.get('event-time') || ''}">
            </div>
          `;
                break;

            case 'team-name':
                inputField = `
            <div class="form-group">
              <label for="team-name">Team Name</label>
              <input type="text" class="form-control" id="team-name" name="team-name" required value="${queryParams.get('team-name') || ''}">
            </div>
          `;
                break;

            case 'team-members':
                inputField = `
            <div class="form-group">
              <label for="team-members">Number of Team Members</label>
              <input type="number" class="form-control" id="team-members" name="team-members" required value="${queryParams.get('team-members') || ''}">
            </div>
          `;
                break;

            case 'team-experience':
                inputField = `
            <div class="form-group">
              <label for="team-experience">Years of Experience in Event</label>
              <input type="number" class="form-control" id="team-experience" name="team-experience" required value="${queryParams.get('team-experience') || ''}">
            </div>
          `;
                break;

            case 'name':
                inputField = `
            <div class="form-group">
              <label for="name">Name</label>
              <input type="text" class="form-control" id="name" name="name" required value="${queryParams.get('name') || ''}">
            </div>
          `;
                break;

            case 'email':
                inputField = `
            <div class="form-group">
              <label for="email">Email</label>
              <input type="email" class="form-control" id="email" name="email" required value="${queryParams.get('email') || ''}">
            </div>
          `;
                break;

                // Add more cases for other selected details

            default:
                break;
        } <
        p > hello < /p>
        formFieldsContainer.innerHTML += inputField;
    });

    registrationForm.addEventListener('submit', function(event) {
        event.preventDefault();

        // Retrieve form data
        const formData = new FormData(registration - Form);
        const formValues = Object.fromEntries(formData);

        // Handle registration submission
        console.log(formValues);
        // ...
          
    });
});