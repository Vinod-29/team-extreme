const express=require("express")
const app=express()
const path=require("path")
const hbs=require("hbs")
const collection=require("./mongodb")

const tempelatePath=path.join(__dirname,'../tempelates')


app.use(express.json())
app.set("view engine","hbs")
app.set("views",tempelatePath)
app.use(express.urlencoded({extended:false}))

app.get("/",(req,res) =>{
   res.render("home")
})
app.get("/login",(req,res) =>{
    res.render("login")
})

app.get("/signup",(req,res)=>{
    res.render("signup")
})
app.get("/about",(req,res)=>{
   res.render("about")
})
app.get("/contact",(req,res)=>{
   res.render("contact")
})
app.get("/forgotpassword",(req,res)=>{
   res.render("forgotpassword")
})
app.get("/organiser_form",(req,res)=>{
   res.render("organiser_form")
})
app.get("/particiant_form",(req,res)=>{
   res.render("particiant_form")
})
app.get("/personaldetail",(req,res)=>{
   res.render("personaldetail")
})
app.get("/privacy",(req,res)=>{
   res.render("privacy")
})
app.get("/resetpassword",(req,res)=>{
   res.render("resetpassword")
})

app.post("/signup",async(req,res)=>{
    const data={
    firstname:req.body.firstname,
    lasttname:req.body.lastname,
    emailid:req.body.emailid,
    phonenumber:req.body.phonenumber,
   password:req.body.password,
   confirmpassword:req.body.confirmpassword
    }

    await collection.insertMany([data])

    res.render("home")

})

app.post("/login",async(req,res)=>{
   try{
    const check=await collection.findOne({name:req.body.name})

   if(check.password===req.body.password){
    res.render("home")
   }
res.send("wrong password")


   }
   catch{
res.send("wrong details")
   }
})



app.listen(3000,()=>{
    console.log("port connected");
})