document.addEventListener('DOMContentLoaded', function() {
    const formGenerator = document.getElementById("form-generator");
    const formLink = document.getElementById("form-link");
    const linkInput = document.getElementById("link");

    formGenerator.addEventListener('submit', function(event) {
        event.preventDefault();

        // Get user input values
        const selectedDetails = Array.from(document.querySelectorAll('input[name="details"]:checked')).map(input => input.value);

        const mandatoryFields = document.getElementById('mandatory-fields').value;

        // Create the registration page link
        const registrationPageLink = generateRegistrationPageLink(selectedDetails, mandatoryFields);

        // Show the registration page link and set its value
        formLink.style.display = 'block';
        linkInput.value = registrationPageLink;
    });

    function generateRegistrationPageLink(details, mandatoryFields) {
        const detailsQuery = encodeURIComponent(JSON.stringify(details));
        const mandatoryFieldsQuery = encodeURIComponent(mandatoryFields);

        return `${window.location.origin}/particiant_form.html?details=${detailsQuery}&mandatoryFields=${mandatoryFieldsQuery}`;  
    }
});